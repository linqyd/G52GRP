<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Chart_model extends CI_Model
{
    protected $DB_TABLE = 'Histroy';

    function __construct()
    {
        parent::__construct();
    }


    public function getData(){

        $query = $this->db->query(
            'SELECT * FROM '.$this->DB_TABLE.' ORDER BY `TIMEV` LIMIT 0,6',
            array()
        );

        return $query->result_array();
    }

}