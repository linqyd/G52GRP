<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: Sylvia
 * Date: 15-3-1
 * Time: 下午7:19
 */


class Mode_model extends CI_Model
{
    public function writeFile($mode){
        $data = "Mode\n".$mode;

        write_file('assets/file/Mode.csv', $data);
    }
}