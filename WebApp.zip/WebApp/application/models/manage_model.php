<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Manage_model extends CI_Model
{
    protected $DB_TABLE = 'CurrentDevice';
    protected $ALT_DB_TABLE = 'availableApp';

    // default
    protected $DEFAULT_MODE = 'Auto';
    protected $DEFAULT_PREFER_TEMP = '10';

    function __construct() {
        parent::__construct();
    }

    public function getCurrentApp() {
        $query = $this->db->query(
            'SELECT * FROM '.$this->DB_TABLE,
            array()
        );

        return $query->result_array();
    }

    public function writeFile(){
        $data = $this->session_model->getSession();

        $this->addAppliance($data);

        $this->deleteAppliance($data);

        $this->session_model->clear();

    }

    public function addAppliance($data)
    {
        $mode = $this->session->userdata('mode');
        if(!isset($mode)){
            $mode = $this->DEFAULT_MODE;
        }

        if(!$data['add']) {
            write_file('assets/file/Create.csv', "");
        }

        else{
            $data2="";

            foreach($data['add'] as $roomID => $appIDs){
                // add room
                if(sizeof($appIDs)==0){
                    break;
                }
                // add appliance
                foreach($appIDs as $appID){
                    $data2 = $data2.$roomID.','.$appID.",1,10,".$mode.','.$this->DEFAULT_PREFER_TEMP."\n";
                }
            }
            write_file('assets/file/Create.csv', $data2);
        }
    }

    public function deleteAppliance($data)
    {
        if(!$data['delete'])
            write_file('assets/file/Delete.csv', "");
        else{
//            1,1,0,20
            $data2="";
            foreach($data['delete'] as $roomID => $appIDs){
                if(sizeof($appIDs)==0){
                    $resources = $this->getCurrentAppByRoom($roomID);
                        foreach($resources as $resource) {
                            $data2 = $data2.$roomID.','.$resource['DID'].",1,10\n";
                        }
                    continue;
                }
                foreach($appIDs as $appID){
                    $data2 = $data2.$roomID.','.$appID.",1,10\n";
                }
            }
            write_file('assets/file/Delete.csv', $data2);
        }
    }

    public function getAvaiableAppByRoom($roomID)
    {
        $query = $this->db->query(
            'SELECT * FROM `'.$this->ALT_DB_TABLE.'` WHERE RID = ?',
            array($roomID)
        );

        return $query->result_array();
    }

    public function getCurrentAppByRoom($roomID){
        $query = $this->db->query(
            'SELECT * FROM `'.$this->DB_TABLE.'` WHERE RID = ?',
            array($roomID)
        );

        return $query->result_array();
    }

} 