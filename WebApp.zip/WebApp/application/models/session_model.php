<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Session_model extends CI_Model
{
    function __construct() {
        parent::__construct();
    }

    public function clear(){
        $this->session->unset_userdata('add');
        $this->session->unset_userdata('delete');
    }

    public function getSession(){
        $data['add'] = $this->session->userdata('add');
        $data['delete'] = $this->session->userdata('delete');

        return $data;
    }

    public function addAppliance($addList){
        $this->session->set_userdata('add', $addList);
    }

    public function deleteAppliance($roomID, $appID){
        $deleteData = $this->session->userdata('delete');

        if(!isset($deleteData[$roomID]))
            $index = 0;
        else
            $index = sizeof($deleteData[$roomID]);

        $deleteData[$roomID][$index] = $appID;

        $this->session->set_userdata('delete', $deleteData);
    }

    public function deleteRoom($roomID){
        $deleteData[$roomID] = [];

        $this->session->set_userdata('delete', $deleteData);
    }

    // for mode operation
    public function setMode($mode){
        $this->session->set_userdata('mode',$mode);
    }

    public function getMode(){
        return $this->session->userdata('mode');
    }

}
