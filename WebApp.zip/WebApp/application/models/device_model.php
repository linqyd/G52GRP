<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Device_model extends CI_Model
{
    protected $DB_TABLE = 'CurrentDevice';

    function __construct()
    {
        parent::__construct();
    }

    public function getData()
    {
        // TODO: read data from db

        $query = $this->db->query(
            'SELECT * FROM '.$this->DB_TABLE,
            array()
        );


//        $this->load->helper('file');
//        read from java output file
//        $rawData = read_file('assets/file/output.txt');
//        $rawData=str_replace(" ","\n",$rawData);
//        $data = explode("\n",$rawData);
//
//        $dataPair = [];
//
//        for($i = 0; $i < sizeof($data); $i++){
//            $dataPair[$i]['name'] = $data[$i];
//            $i++;
//            $dataPair[$i-1]['condition'] = $data[$i];
//        }

        return $query->result_array();
    }

    public function writeData($data)
    {
        write_file('assets/file/input.txt', $data);
    }

}