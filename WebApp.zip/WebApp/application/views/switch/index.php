
<!--/**-->
<!-- * Created by PhpStorm.-->
<!-- * User: Sylvia-->
<!-- * Date: 15-2-3-->
<!-- * Time: 下午1:07-->
<!-- */-->
<script>
    $(document).ready(function(){
        $("div.test > p > span").click(function() {

            if($(this).attr('class') == 'triangle-down'){
                toggle = false
            }
            else{
                toggle = true;
            }

            if(!toggle){
                $(this).parents('div.row').next('div.row').children().children().removeAttr('style');
                $(this).removeClass("triangle-down").addClass("triangle-up");
            }
            else{
                $(this).removeClass("triangle-up").addClass("triangle-down");
                $(this).parents('div.row').next('div.row').children().children().attr("style","display:none;");
            }
        });

        $("#apply").click(function(){
            var myData = [];
            var i = 0;

            $('.switch').each(function(){
                if($(this).children().hasClass('bootstrap-switch-on')){
                    myData[i] = 'ON';
                    i++;
                }
                else{
                    myData[i] = 'OFF';
                    i++;
                }
            });

            $.post('<? echo BASE_URI;?>/switch/change',{ 'switchCondition': myData } );
//                TODO : remember delete here
            console.log(myData);
        });

    });

</script>
<div id="main-pic">
    <div class="container" id="wrap">
        <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-6 test">
            </div>
            <div class=" col-lg-3 col-md-3 col-sm-3 consumption">
                <h5>last 12 hours consumption</h5>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-3 consumption">
                <h5>last 24 hours consumption</h5>
            </div>
        </div>

        <!--     repeat start   -->
        <?php if(!isset($switchDatas)):?>
            <div>
                No Appliance Yet
            </div>
        <?php else:?>
            <?php foreach ($switchDatas as $room => $appState): ?>

                <div class="row">
                    <div class="col-lg-3">
                        <h3 class="text-left"><?php echo "Room "; echo $room;?></h3>
                    </div>
                </div>

            <?php foreach ($appState as $app => $state): ?>
            <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-6 test">
                    <p><?php echo "Appliance "; echo $app ;?><span class="triangle-down"></span></p>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-3 consumption">
                    <p>12 kw H</p>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-3 consumption">
                    <p>21 kw H</p>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                    <p class="switch">
                        <?php if ($mode == 'custo'): ?>
                                <?php if ($state=='1'): ?>
                            <input type="checkbox" checked data-on-color="default">
                        <?php else: ?>
                            <input type="checkbox" data-on-color="default">
                        <?php endif; ?>
                            <?php else: ?>
                                <?php if ($state=='1'): ?>
                            <input type="checkbox" checked data-on-color="default" disabled>
                        <?php else: ?>
                            <input type="checkbox" data-on-color="default" disabled>
                        <?php endif; ?>
                            <?php endif;?>
                    </p>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-10 col-xs-offset-1">
                    <div class="alert alert-success" role="alert" style="display: none;">
                        <p><strong>last 12 hours consumption: </strong>12 kw H</p>
                        <p><strong>last 24 hours consumption: </strong>20 kw H</p>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            <?php endforeach; ?>
        <?php endif;?>
        <!--     repeat ends   -->

        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-8 col-xs-offset-2 col-sm-offset-3">
                <button type="button" class="btn btn-default btn-lg btn-block" id="apply">apply settings</button>
            </div>
        </div>
        <a>Edit Devices</a>

    </div>
</div>
</body>
