<!--/**-->
<!-- * Created by PhpStorm.-->
<!-- * User: Sylvia-->
<!-- * Date: 15-2-3-->
<!-- * Time: 下午12:57-->
<!-- */-->
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
    <link type="text/css" rel="stylesheet" href="<?php echo BASE_URI; ?>/assets/css/bootstrap.min.css">
    <link type="text/css"  rel="stylesheet" href="<?php echo BASE_URI; ?>/assets/css/custom-global.css">
    <link type="text/css" rel="stylesheet" href="<?php echo BASE_URI; ?>/assets/css/custome-functionality.css">
    <link type="text/css" href="<?php echo BASE_URI; ?>/assets/css/bootstrap-switch.css" rel="stylesheet">
    <link type="text/css" href="<?php echo BASE_URI; ?>/assets/css/main.css" rel="stylesheet">
    <link type="text/css" href="<?php echo BASE_URI; ?>/assets/css/highlight.css" rel="stylesheet">

    <script src="<?php echo BASE_URI; ?>/assets/js/jquery-2.1.3.js"></script>
    <script src="<?php echo BASE_URI; ?>/assets/js/bootstrap.js"></script>
    <script src="<?php echo BASE_URI; ?>/assets/js/bootstrap-switch.js"></script>
    <script src="<?php echo BASE_URI; ?>/assets/js/highlight.js"></script>
    <script src="<?php echo BASE_URI; ?>/assets/js/main.js"></script>
</head>

<body>
<nav class="navbar navbar-inverse navbar-fixed-top navbar-collapse" role="navigation">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#" style="padding: 9px;"><img src="<?php echo BASE_URI; ?>/assets/img/logo.gif" height="35px;"></a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <?php if($page == 'manage'):?>
                    <li class="active"><a href="<?php echo BASE_URI; ?>/manage/">Manage <span class="sr-only">(current)</span></a></li>
                <?php else:?>
                    <li><a href="<?php echo BASE_URI; ?>/manage/">Manage</a></li>
                <?php endif;?>

                <?php if($page == 'chart'):?>
                    <li class="active"><a href="<?php echo BASE_URI; ?>/chart/">Chart <span class="sr-only">(current)</span></a></li>
                <?php else:?>
                    <li><a href="<?php echo BASE_URI; ?>/chart/">Chart</a></li>
                <?php endif;?>

                <?php if($page == 'device'):?>
                    <li class="active"><a href="<?php echo BASE_URI; ?>/chart/">Devices <span class="sr-only">(current)</span></a></li>
                <?php else:?>
                    <li><a href="<?php echo BASE_URI; ?>/switch/">Devices</a></li>
                <?php endif;?>

                <?php if($page == 'mode'):?>
                    <li class="active"><a href="<?php echo BASE_URI; ?>/chart/">Mode <span class="sr-only">(current)</span></a></li>
                <?php else:?>
                    <li><a href="<?php echo BASE_URI; ?>/mode/">Mode</a></li>
                <?php endif;?>
            </ul>
            
            <ul class="nav navbar-nav navbar-right">
                <?php if($page == 'setting'):?>
                    <li class="active"><a href="<?php echo BASE_URI; ?>/chart/">Setting <span class="sr-only">(current)</span></a></li>
                <?php else:?>
                    <li><a href="<?php echo BASE_URI; ?>/setting/">Setting</a></li>
                <?php endif;?>
            </ul>

        </div><!-- /.navbar-collapse -->
    </div>
</nav>