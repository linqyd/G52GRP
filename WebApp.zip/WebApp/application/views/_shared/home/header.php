<!DOCTYPE html>
<html>
	<head lang="en">
		<meta charset="UTF-8">
		<title>G52GRP</title>
		<?php include('auto_config.php'); ?>
	    <link type="text/css" rel="stylesheet" href="/assets/css/bootstrap.min.css">
	    <link type="text/css"  rel="stylesheet" href="/assets/css/custom.css">

		<script type="text/javascript" src="/assets/js/main.js"></script>
	</head>
	<body>