        <?php if ($this->ion_auth->logged_in()){?>
            <div class="logout_box">
                <a href="/auth/logout">Logout</a>
            </div>
        <?php } ?>
	</body>
	<footer>

	</footer>
</html>