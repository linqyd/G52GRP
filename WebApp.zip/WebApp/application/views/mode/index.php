<div id="main-pic">
    <div class="container" id="wrap">

        <form class="form-horizontal" role="form" method="post" action="<?php echo BASE_URI; ?>/mode/select">
            <div class="row">
                <?php if($mode == 'Auto'):?>
                    <div class="col-lg-8 col-lg-offset-1"><h2>Auto Mode(Current Mode)</h2></div>
                <?php else:?>
                    <div class="col-lg-8 col-lg-offset-1"><h2>Auto Mode</h2></div>
                <?php endif?>
                <div class="col-lg-2 col-lg-offset-1"><button type="submit" class="btn btn-default btn-block">Select</button></div>
                <input type="hidden" name="mode" value="Auto">
            </div>
            <div class="row">
                <div class="col-lg-9 col-lg-offset-1">
                    <p class="text-left"><strong>Description:</strong>
                        Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.
                        Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus
                        mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa
                    </p>
                </div>
            </div>
        </form>
        <form class="form-horizontal" role="form" method="post" action="<?php echo BASE_URI; ?>/mode/select">
            <div class="row">
                <?php if($mode == 'Summer'):?>
                    <div class="col-lg-8 col-lg-offset-1"><h2>Spring/Summer Mode(Current Mode)</h2></div>
                <?php else:?>
                    <div class="col-lg-8 col-lg-offset-1"><h2>Spring/Summer Mode</h2></div>
                <?php endif?>
                <div class="col-lg-2 col-lg-offset-1"><button type="submit" class="btn btn-default btn-block">Select</button></div>
                <input type="hidden" name="mode" value="Summer">
            </div>
            <div class="row">
                <div class="col-lg-9 col-lg-offset-1">
                    <p class="text-left"><strong>Description:</strong>
                        Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.
                        Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus
                        mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa
                        quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo,
                        rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium.
                    </p>
                </div>
            </div>
        </form>
        <form class="form-horizontal" role="form" method="post" action="<?php echo BASE_URI; ?>/mode/select">
            <div class="row">
                <?php if($mode == 'Winter'):?>
                    <div class="col-lg-8 col-lg-offset-1"><h2>Winter/Autumn Mode(Current Mode)</h2></div>
                <?php else:?>
                    <div class="col-lg-8 col-lg-offset-1"><h2>Winter/Autumn Mode</h2></div>
                <?php endif?>
                <div class="col-lg-2 col-lg-offset-1"><button type="submit" class="btn btn-default btn-block">Select</button></div>
                <input type="hidden" name="mode" value="Winter">
            </div>
            <div class="row">
                <div class="col-lg-9 col-lg-offset-1">
                    <p class="text-left"><strong>Description:</strong>
                        Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.
                        Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus
                        quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo,
                        rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium.
                    </p>
                </div>
            </div>
        </form>
        <a href="#">Customioze Your Own Mode</a>
    </div>
</div>
</body>
