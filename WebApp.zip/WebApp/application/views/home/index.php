    <div id="main-pic">
        <div class="container-fluid" id="text-holder">
            <div class="logo">
                <img src="/assets/img/logo-alter.png" height="200px">
            </div>
            <div class="row">
                <div class="col-xs-8 col-xs-offset-2">
                    <h1> MARVEL KNIGHTS </h1>
                    <p style="font-size: 18pt"> Smart Home Total Solution </p>
                    <a class="join_button" href="/auth/register"><button style="margin-bottom:1px" class="center-block btn-lg btn-default"> Join Today </button></a>
                    <a class="sign_in" href="/auth/login">Already have an account?</a>
                </div>
            </div>
        </div>
    </div>
