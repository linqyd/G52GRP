<div id="main-pic">
    <div class="container-fluid" id="text-holder">
        <div class="row">
            <div class="col-lg-4 col-lg-offset-4 col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-8 col-xs-offset-2">
                <div class="bg" style="background-color: rgba(255,255,255,0.8);margin-top: 28%; height: 200px; padding: 12% 5%;border-radius: 8px;">
                <div class="alert alert-info" role="alert">
                    Changes have been applied. Click
                    <a href="<?php echo BASE_URI.'/manage/';?>" class="alert-link"> Here</a>
                     Back to the previous Page.
                </div>
            </div>
        </div>
    </div>
</div>