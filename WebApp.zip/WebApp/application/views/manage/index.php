<style type="text/css">
    body,a,a:hover{
        color: #6e6e6e;
    }
    .btn-default{
        height: 35px;
        background-color: transparent;
        border: 2px solid #6e6e6e;
        color: #6e6e6e;
    }
    .glyphicon{
        margin-right: 5px;
    }


</style>
<div id="main-pic">
    <div class="container" id="wrap">
        <form class="form-horizontal" role="form" method="post" action="<?php echo BASE_URI; ?>/manage/confirm">
            <h3>Add New Appliances</h3>

            <div class="form-group">
                <div class="rooms">
                    <div class="row">
                        <label class="col-lg-2 col-md-3 col-sm-3 col-xs-4 control-label" for="room">
                            <span class="glyphicon glyphicon-home" aria-hidden="true"></span>New Room:
                        </label>
                        <div class="col-lg-7 col-lg-offset-1 col-md-7 col-sm-6 col-xs-5">
                            <select id="basic" class="form-control room" name="room-0">
                                <option value="0">Room 0</option>
                                <option value="1">Room 1</option>
                                <option value="2">Room 2</option>
                                <option value="3">Room 3</option>
                                <option value="4">Room 4</option>
                            </select>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-3">
                            <button type="button" class="btn btn-default btn-rm" id="undoRoom">Remove</button>
                        </div>
                    </div>

                    <div class="apps">
                    </div>
                    <a href="#" id="add-app">+ Add More Appliance</a>
                    <hr>
                </div>
            </div>

            <a href="#" id="add-room">+ Add A New Room</a>
        </form>

        <hr>
<!--Display Current Appliances-->
        <h3>Current Appliances</h3>
        <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-6 test">
            </div>
            <div class=" col-lg-3 col-md-3 col-sm-3 consumption">
                <h5>last 12 hours consumption</h5>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-3 consumption">
                <h5>last 24 hours consumption</h5>
            </div>
        </div>
        <?php if(!isset($curApps)): ?>
            <div>No Appliance Yet</div>
        <?php else:?>

            <?php foreach ($curApps as $roomID => $appIDList):?>
                <div class="cur-room">
                    <div class="row">
                        <div class="col-lg-10 col-md-4 col-sm-4 col-xs-6 test">
                            <h4 style="text-align: left;">Room <?php echo "$roomID"?>:</h4>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                            <button type="button" class="btn btn-default btn-rm" id="deleteRoom">Remove</button>
                            <input type="hidden" id="ipt" value="<?php echo "$roomID"?>">
                        </div>
                    </div>

                    <?php foreach ($appIDList as $appID => $value): ?>
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-6 test">
                                <p><strong>DEVICE NAME <?php echo $appID;?></strong> <span class="triangle-down"></span></p>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-3 consumption">
                                <p><?php echo $value;?> kw H</p>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-3 consumption">
                                <p>21 kw H</p>
                            </div>
                            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-6">
                                <span class="glyphicon glyphicon-remove" aria-hidden="true" style="top:10px;" id="deleteApp"></span>
                                <input type="hidden" id="ipt" value="<?php echo $appID; ?>" data-room-id="<?php echo $roomID; ?>">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-10 col-xs-offset-1">
                                <div class="alert alert-success" role="alert" style="display: none;">
                                    <p><strong>last 12 hours consumption: </strong>12 kw H</p>
                                    <p><strong>last 24 hours consumption: </strong>20 kw H</p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach;?>

                    <hr>
                </div>
            <?php endforeach?>
        <?php endif;?>


        <button id="special" class="btn btn-default">Comfirm</button>

        <script>
            $(document).ready(function () {

                var options = '';

                $("body").on('change','select.room',function(){
                    $.ajax({
                        type: "POST",
                        url: "<?php echo BASE_URI; ?>/manage/get_app",
                        data: {roomID: $(this).val()}
                        }).done(function(appData){
                            options = '';
                            Data = JSON.parse(appData);
                            for(var appID in Data){
                                options = options + '<option value="'+ Data[appID] +'"> appliance ' + Data[appID] + '</option>\n';
                            }
                        });
//                    end done
                    $(this).parents().parents().next('.apps').empty();
                });

                // remove room
                $("body").on('click','button.btn-rm',function(){
                    $(this).parent().parent().parent().remove();

                    var method = $(this).attr('id');
                    var roomID;

                    if(method == 'deleteRoom')
                        roomID = $(this).next('#ipt').attr('value');

                    $.post('<?php echo BASE_URI;?>/manage/',{'method' : method, 'roomID' : roomID});
                });

                // remove app
                $("body").on('click','span.glyphicon',function(){
                    $(this).parent().parent().remove();

                    var method = $(this).attr('id');
                    var appID, roomID;

                    if(method == 'deleteApp'){
                        appID = $(this).next('#ipt').attr('value');
                        roomID = $(this).next('#ipt').attr('data-room-id');
                    }

                    $.post('<?php echo BASE_URI;?>/manage/',{'method' : method, 'roomID' : roomID, 'appID' : appID});
                });

                var j = 1;
                $("body").on('click',"#add-app",function(){
                    var roomNum = $(this).parent().children().children().children("#basic").attr('name');
//                    alert(roomId);
                    var roomID = $(this).parent().children().children().children("#basic").val();
                    if(roomID == 0){
                        var child = '<div class="row">' +
                            '<label class="col-lg-2 col-md-3 col-sm-3 col-xs-4 control-label" for="basic"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span>Appliance:</label>' +
                            '<div class="col-lg-7 col-lg-offset-1 col-md-7 col-sm-6 col-xs-5">' +
                            '<select id="basic" class="form-control app" name="'+roomNum+'-app-'+j+'" data-room-id="'+ roomID +'">'+
                            <?php foreach($defaultOpts as $appID){
                                echo '\'<option value="'.$appID.'"> appliance '.$appID.'</option>\n\'';
                                echo '+';
                                }
                                ?>
                            '</select>' +
                            '</div>' +
                            '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-3">' +
                            '<span class="glyphicon glyphicon-remove" aria-hidden="true" style="top:10px;" id="undoApp"></span>' +
                            '</div>' +
                            '</div>';
                    }
                    else{
                        child = '<div class="row">' +
                            '<label class="col-lg-2 col-md-3 col-sm-3 col-xs-4 control-label" for="basic"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span>Appliance:</label>' +
                            '<div class="col-lg-7 col-lg-offset-1 col-md-7 col-sm-6 col-xs-5">' +
                            '<select id="basic" class="form-control app" name="'+roomNum+'-app-'+j+'" data-room-id="'+ roomID +'">' +
                            options +
                            '</select>' +
                            '</div>' +
                            '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-3">' +
                            '<span class="glyphicon glyphicon-remove" aria-hidden="true" style="top:10px;" id="undoApp"></span>' +
                            '</div>' +
                            '</div>';
                    }


                    $(this).parent(".rooms").children(".apps").append(child);
                    j++;
                });

                var i = 1;
                $("body").on('click',"#add-room",function(){
                    var child = '<div class="rooms">' +
                            '<div class="row">' +
                        '<label class="col-lg-2 col-md-3 col-sm-3 col-xs-4 control-label" for="room">' +
                    '<span class="glyphicon glyphicon-home" aria-hidden="true"></span>New Room:' +
                        '</label>' +
                    '<div class="col-lg-7 col-lg-offset-1 col-md-7 col-sm-6 col-xs-5">' +
                    '<select id="basic" class="form-control room" name="room-'+ i +'">' +
                    '<option value="0">Room 0</option>' +
                    '<option value="1">Room 1</option>' +
                    '<option value="2">Room 2</option>' +
                    '<option value="3">Room 3</option>' +
                    '<option value="4">Room 4</option>' +
                    '</select>' +
                    '</div>' +
                    '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-3">' +
                    '<button type="button" class="btn btn-default btn-rm" id="undoRoom">Remove</button>' +
                    '</div>' +
                            '</div>' +
                    '<div class="apps">' +
                    '</div>' +
                    '<a href="#" id="add-app">+ Add More Appliance</a>' +
                    '</div>' +
                    '<hr>';

                    $(this).parent(".form-horizontal").children(".form-group").append(child);

                    i++;
                });

                $("#special").on('click',function(){
                    $('form').submit();
                });

            });
        </script>

    </div>
</div>