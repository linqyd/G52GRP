<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Switch_controller extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    public function index() {
        $data['page'] = 'device';

        $states = $this->device_model->getData();

        foreach($states as $state){
            $RID = $state['RID'];
            $DID = $state['DID'];
            $Dstate = $state['STATE'];

            $data['switchDatas'][$RID][$DID] = $Dstate;
        }

        //TODO :$data['mode'] = $this->session_model->getMode();
        $data['mode'] = 'wa';


//        render the hpage
        $this->load->view('_shared/functionality/header',$data);
        $this->load->view('switch/index',$data);
        $this->load->view('_shared/functionality/footer');
    }

    public function change(){

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            $numOfDevice = count($_POST['switchCondition']);

            $data = $numOfDevice.'';

            for($i = 0; $i < $numOfDevice; $i++ ){
                $data = $data.' '.$_POST['switchCondition'][$i];
            }

            $this->device_model->wirteData($data);

        }
    }

    function add_to_file($line, $file){
        $current = file_get_contents($file);
        $current .= $line."\n";
        file_put_contents($file, $current);
        die();
    }

    public function error_404()
    {
        echo '404';
    }

}
