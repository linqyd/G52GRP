<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Manage_controller extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
    }

    public function index() {
        $data['page'] = 'manage';
        $apps = $this->manage_model->getAvaiableAppByRoom('0');

        $i = 0;
        foreach($apps as $app){
            $data['defaultOpts'][$i] = $app['DID'];
            $i++;
        }

        if($_SERVER['REQUEST_METHOD'] === 'POST'){
            $method = $_POST['method'];

            switch($method){
                case 'deleteRoom':
                    $this->session_model->deleteRoom($_POST['roomID']);
                    break;
                case 'deleteApp':
                    $this->session_model->deleteAppliance($_POST['roomID'], $_POST['appID']);
                    break;
            }
        }

        $curApps = $this->manage_model->getCurrentApp();

        foreach($curApps as $curApp){
            $RID = $curApp['RID'];
            $DID = $curApp['DID'];
            // comsumption
            $VALUE = $curApp['DVALUE'];

            $data['curApps'][$RID][$DID] = $VALUE;
        }

//        render the page
        $this->load->view('_shared/functionality/header',$data);
        $this->load->view('manage/index',$data);
        $this->load->view('_shared/functionality/footer');
    }

    public function get_app(){
        if($_SERVER['REQUEST_METHOD']==='POST'){
            $roomID = $_POST['roomID'];
        }

        $apps = $this->manage_model->getAvaiableAppByRoom($roomID);
        $i = 0;
        foreach($apps as $app){
            $appData['app'.$i] = $app['DID'];
            $i++;
        }

        echo json_encode($appData);
    }

    public function confirm(){
        $addList = [];

        if($_SERVER['REQUEST_METHOD'] === 'POST'){
            $roomPattern = '/^room-[0-9]+$/';

            foreach($_POST as $key => $value){
                // $key is a room ID
                if(preg_match($roomPattern,$key)==1){
                    $roomID = $value;
                    $addList[$roomID] = [];

                    foreach($_POST as $key2 => $value2){
                        if((preg_match($roomPattern,$key2)==0) && (strpos($key2,$key)===0)){
                            $appID = $value2;
                            array_push($addList[$roomID],$appID);
                        }
                    }
                }
            }
            $this->session_model->addAppliance($addList);

            $this->manage_model->writeFile();

            redirect('/manage/success', 'refresh');
        }
    }

    function success(){
        $data['page'] = 'manage';
        $this->load->view('_shared/functionality/header',$data);
        $this->load->view('manage/success');
        $this->load->view('_shared/functionality/footer');
    }
}
