<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: Sylvia
 * Date: 15-2-22
 * Time: 上午11:29
 */

class Mode_controller extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    public function index(){
        $data['page'] = 'mode';

        $data['mode'] = $this->session->userdata('mode');

        //        render the hpage
        $this->load->view('_shared/functionality/header',$data);
        $this->load->view('mode/index',$data);
        $this->load->view('_shared/functionality/footer');
    }


    public function select(){
        $this->session_model->setMode($_POST['mode']);
        $this->mode_model->writeFile($_POST['mode']);

        redirect('/mode/success', 'refresh');
    }


    function success(){
        $data['page'] = 'mode';

        $this->load->view('_shared/functionality/header',$data);
        $this->load->view('mode/success');
        $this->load->view('_shared/functionality/footer');
    }

}