<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Chart_controller extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    public function index(){
        $data['page'] = 'chart';

//        get data
        $resource = $this->chart_model->getData();

        foreach( $resource as $record){
            $temp = explode(' ',$record['TIMEV']);
            $date = $temp[0];
            $data['historyData'][$date]= $record['SDVALUE'];
        }

        //render the page
        $this->load->view('_shared/functionality/header',$data);
        $this->load->view('chart/index',$data);
        $this->load->view('_shared/functionality/footer');
    }
}